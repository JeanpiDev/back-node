/* eslint-disable prettier/prettier */
// src/modules/database/database.service.ts
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, FindOneOptions, FindManyOptions, FindOptionsWhere } from 'typeorm';

@Injectable()
export class EntitiesService<T> {
    private readonly repository: Repository<T>;

    constructor(
        @InjectRepository(Object)
        private readonly rep: Repository<T>,
    ) {
        this.repository = rep;
    }

    async findAll(): Promise<T[]> {
        return await this.repository.find();
    }

    //Inserta tomando en cuenta todos los campos de la entidad
    async create(entidad: T): Promise<T> {
        return await this.repository.save(entidad);
    }

    // Nueva función de búsqueda
    async search(conditions: FindOptionsWhere<T>): Promise<T[]> {
        const options: FindManyOptions<T> = { where: conditions };
        return this.repository.find(options);
    }

    // Nueva función de edición
    async edit(conditions: FindOptionsWhere<T>, data: Partial<T>): Promise<T | null> {
        await this.repository.update(conditions, data as any);
        const options: FindOneOptions<T> = { where: conditions };
        return this.repository.findOne(options)?? null;
    }

    // Nueva función de inserción PND
    async insert(data: Partial<T>): Promise<T> {
        const newEntity = this.repository.create(data as any);
        return this.repository.save(newEntity) as Promise<T>; 
    }

    // Nueva función de eliminación
    async remove(id: number): Promise<boolean> {
        const deleteResult = await this.repository.delete(id);
        return deleteResult.affected > 0;
    }

    
    async count(conditions: FindOptionsWhere<T>): Promise<number> {
        const options: FindManyOptions<T> = { where: conditions };
        return this.repository.count(options);
    }
}