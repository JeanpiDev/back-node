/* eslint-disable prettier/prettier */
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { EntitiesService } from '../database/entities.service';
import { Customers, Users, ContactTypes, ContactsEmergency, CustomersBlocked, Contacts, Roles, UsersTypes } from '../database/db.entities';


@Injectable()
export class CustomerService extends EntitiesService<Customers>{
  constructor(
    @InjectRepository(Customers)
    private readonly E_Repository: Repository<Customers>,
  ) {
     super(E_Repository);
  }
}

@Injectable()
export class UsersService extends EntitiesService<Users>{
  constructor(
    @InjectRepository(Users)
    private readonly E_Repository: Repository<Users>,
  ) {
     super(E_Repository);
  }
}

@Injectable()
export class ContactTypesService extends EntitiesService<ContactTypes> {
  constructor(
    @InjectRepository(ContactTypes)
    private readonly E_Repository: Repository<ContactTypes>,
  ) {
    super(E_Repository);
  }
}

@Injectable()
export class ContactsEmergencyService extends EntitiesService<ContactsEmergency> {
  constructor(
    @InjectRepository(ContactsEmergency)
    private readonly E_Repository: Repository<ContactsEmergency>,
  ) {
    super(E_Repository);
  }
}

@Injectable()
export class CustomersBlockedService extends EntitiesService<CustomersBlocked> {
  constructor(
    @InjectRepository(CustomersBlocked)
    private readonly E_Repository: Repository<CustomersBlocked>,
  ) {
    super(E_Repository);
  }
}

@Injectable()
export class ContactsService extends EntitiesService<Contacts> {
  constructor(
    @InjectRepository(Contacts)
    private readonly E_Repository: Repository<Contacts>,
  ) {
    super(E_Repository);
  }
}

@Injectable()
export class RolesService extends EntitiesService<Roles> {
  constructor(
    @InjectRepository(Roles)
    private readonly E_Repository: Repository<Roles>,
  ) {
    super(E_Repository);
  }
}

@Injectable()
export class UsersTypesService extends EntitiesService<UsersTypes> {
  constructor(
    @InjectRepository(UsersTypes)
    private readonly E_Repository: Repository<UsersTypes>,
  ) {
    super(E_Repository);
  }
}