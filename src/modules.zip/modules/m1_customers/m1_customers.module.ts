// customer.module.ts
import { Module } from '@nestjs/common';
import { CustomerService, UsersService, ContactTypesService, ContactsEmergencyService, CustomersBlockedService, ContactsService, RolesService, UsersTypesService } from './m1_customers.service';
import { CustomerController } from './m1_customers.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Customers, Users, ContactTypes, ContactsEmergency, CustomersBlocked, Contacts, Roles, UsersTypes } from '../database/db.entities';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      Customers,
      Users,
      ContactTypes,
      ContactsEmergency,
      CustomersBlocked,
      Contacts,
      Roles,
      UsersTypes
    ])
  ],
  providers: [
    CustomerService,
    UsersService,
    ContactTypesService,
    ContactsEmergencyService,
    CustomersBlockedService,
    ContactsService,
    RolesService,
    UsersTypesService
  ],
  controllers: [CustomerController],
  exports: [CustomerService,UsersService,ContactTypesService,ContactsEmergencyService,CustomersBlockedService,ContactsService,RolesService,UsersTypesService
  ]
})
export class CustomerModule {}