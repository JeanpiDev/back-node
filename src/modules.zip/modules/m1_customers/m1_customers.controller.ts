import { Controller, Get, Post, Body } from '@nestjs/common';
import { CustomerService, UsersService, ContactTypesService, ContactsEmergencyService, CustomersBlockedService, ContactsService, RolesService, UsersTypesService } from './m1_customers.service';
import { Customers, Users, ContactTypes, ContactsEmergency, CustomersBlocked, Contacts, Roles, UsersTypes } from '../database/db.entities';

@Controller('customers')
export class CustomerController {
  constructor(private readonly customerService: CustomerService) {}

}