import { Column, Entity } from "typeorm";

@Entity("logs_2021_09_01", { schema: "public" })
export class Logs_2021_09_01 {
  @Column("integer", { name: "id", default: () => "0" })
  id: number;

  @Column("character varying", { name: "imei", nullable: true, length: 20 })
  imei: string | null;

  @Column("text", { name: "data", nullable: true })
  data: string | null;

  @Column("character varying", { name: "error", nullable: true, length: 255 })
  error: string | null;

  @Column("smallint", { name: "status", nullable: true })
  status: number | null;

  @Column("timestamp without time zone", {
    name: "created_at",
    nullable: true,
    default: () => "CURRENT_TIMESTAMP",
  })
  createdAt: Date | null;

  @Column("timestamp without time zone", { name: "updated_at", nullable: true })
  updatedAt: Date | null;
}
