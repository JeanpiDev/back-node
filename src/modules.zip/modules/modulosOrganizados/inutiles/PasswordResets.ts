import { Column, Entity, Index } from "typeorm";

@Index("idxpassword_resets_email", ["email"], {})
@Entity("password_resets", { schema: "public" })
export class PasswordResets {
  @Column("character varying", { name: "email", length: 191 })
  email: string;

  @Column("character varying", { name: "token", length: 191 })
  token: string;

  @Column("timestamp without time zone", { name: "created_at", nullable: true })
  createdAt: Date | null;
}
