import { Column, Entity } from "typeorm";

@Entity("event_type_device_plot_header_type", { schema: "public" })
export class EventTypeDevicePlotHeaderType {
  @Column("integer", { name: "event_type_id" })
  eventTypeId: number;

  @Column("integer", { name: "brand_id" })
  brandId: number;

  @Column("integer", { name: "device_plot_header_type_id" })
  devicePlotHeaderTypeId: number;

  @Column("character varying", {
    name: "device_plot_header_type_code",
    nullable: true,
    length: 45,
  })
  devicePlotHeaderTypeCode: string | null;

  @Column("integer", { name: "code_ws", nullable: true })
  codeWs: number | null;
}
